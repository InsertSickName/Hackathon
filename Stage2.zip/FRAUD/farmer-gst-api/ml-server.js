// ml-server.js
import express from "express";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const PORT = process.env.ML_PORT || 9000;

app.use(express.json());

app.post("/predict", (req, res) => {
  const { features } = req.body || {};
  const {
    avgRateDiff = 0,
    totalSubsidyClaimed = 0,
    eligibleSubsidy = 0,
    gstMatchRatio = 1,
    purchaseCount = 0
  } = features || {};

  let score = 0.0;
  score += Math.max(0, avgRateDiff) * 0.3;
  score += totalSubsidyClaimed > eligibleSubsidy ? 0.4 : 0.0;
  score += (1 - gstMatchRatio) * 0.2;
  score += purchaseCount === 0 ? 0.2 : 0.0;

  const probability = Math.max(0, Math.min(1, score));
  const fraud = probability > 0.5;

  res.json({
    fraud,
    probability,
    modelVersion: "stub-heuristic-1.1",
    explanations: { avgRateDiff, totalSubsidyClaimed, eligibleSubsidy, gstMatchRatio, purchaseCount }
  });
});

app.listen(PORT, () => console.log(`🤖 ML stub running on http://localhost:${PORT}`));
