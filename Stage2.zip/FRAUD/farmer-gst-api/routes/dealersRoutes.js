// routes/dealersRoutes.js
import express from "express";
import { authenticateToken } from "../middleware/auth.js";
import { farmers } from "../models/farmerModels.js";
const router = express.Router();

router.get("/:farmerId/dealers", authenticateToken, (req, res) => {
  const farmer = farmers.find(f => f.farmerId === req.params.farmerId);
  if (!farmer) return res.status(404).json({ error: "Farmer not found" });
  res.json({ farmerId: farmer.farmerId, dealers: farmer.dealers });
});

export default router;
