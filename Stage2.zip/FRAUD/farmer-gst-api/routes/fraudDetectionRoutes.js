// routes/fraudDetectionRoutes.js
import express from "express";
import fetch from "node-fetch";
import { authenticateToken } from "../middleware/auth.js";
import { farmers } from "../models/farmerModels.js";

const router = express.Router();
const ML_URL = process.env.ML_URL || "http://localhost:9000/predict";

router.get("/:farmerId/dealers/:gstin/fraud-prediction", authenticateToken, async (req, res) => {
  const { farmerId, gstin } = req.params;
  const farmer = farmers.find(f => f.farmerId === farmerId);
  if (!farmer) return res.status(404).json({ error: "Farmer not found" });

  const dealer = farmer.dealers.find(d => d.gstin === gstin);
  if (!dealer) return res.status(404).json({ error: "Dealer not linked to farmer" });

  const transactions = farmer.transactions || [];
  // Features for ML (replace with real computations later)
  const avgRateDiff = 0.1;
  const totalSubsidyClaimed = farmer.subsidyEligibility?.amount || 0;
  const eligibleSubsidy = 6000;
  const gstMatchRatio = 1;
  const purchaseCount = transactions.length;

  try {
    const mlRes = await fetch(ML_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        features: { avgRateDiff, totalSubsidyClaimed, eligibleSubsidy, gstMatchRatio, purchaseCount }
      })
    });
    const mlData = await mlRes.json();
    return res.json({
      farmerId,
      gstin,
      fraudProbability: mlData.probability,
      fraud: mlData.fraud,
      modelVersion: mlData.modelVersion,
      explanations: mlData.explanations
    });
  } catch (e) {
    return res.status(500).json({ error: "ML service unavailable", details: e.message });
  }
});

export default router;
