// routes/loginRoutes.js
import express from "express";
const router = express.Router();

const DEMO_USER = { username: "admin", password: "password123" };

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username === DEMO_USER.username && password === DEMO_USER.password) {
    return res.json({ token: process.env.JWT_SECRET, user: { username } });
  }
  return res.status(401).json({ error: "Invalid credentials" });
});

export default router;
