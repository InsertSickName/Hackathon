// models/farmerModels.js

export class Farmer {
  constructor({
    farmerId,
    name,
    aadhaar,
    mobile,
    landHolding,
    crops = [],
    dealers = [],
    transactions = [],
    subsidyEligibility = {},
  }) {
    this.farmerId = farmerId;
    this.name = name;
    this.aadhaar = aadhaar;
    this.mobile = mobile;
    this.landHolding = landHolding;
    this.crops = crops;
    this.dealers = dealers;
    this.transactions = transactions;
    this.subsidyEligibility = subsidyEligibility;
  }
}

// Fixed 5 dealers
const dealerPool = [
  { gstin: "29ABCDE1234F1Z5", name: "AgroMart", location: "Bangalore" },
  { gstin: "29XYZ9876F1Z5", name: "GreenGrow", location: "Mysore" },
  { gstin: "29LMN1234F1Z5", name: "FarmSupplyCo", location: "Mandya" },
  { gstin: "29DEF1234F1Z5", name: "CropCare", location: "Hubli" },
  { gstin: "29PQR9876F1Z5", name: "AgriHub", location: "Tumkur" }
];

// Utility random helpers
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function pick(arr, n = 1) {
  return [...arr].sort(() => 0.5 - Math.random()).slice(0, n);
}

export const farmers = [];

// Generate 20 farmers with diverse attributes
const cropPool = ["Wheat", "Rice", "Maize", "Cotton", "Sugarcane", "Soybean", "Millet", "Pulses"];

for (let i = 1; i <= 20; i++) {
  const farmerId = `FARM${String(i).padStart(3, "0")}`;
  const name = `Farmer ${i}`;
  const aadhaar = `${1000 + i}-${randInt(1000, 9999)}-${randInt(1000, 9999)}`;
  const mobile = `98${randInt(10000000, 99999999)}`;
  const landHolding = `${randInt(1, 12)} acres`;
  const crops = pick(cropPool, 2);
  const subsidyEligibility = {
    scheme: i % 3 === 0 ? "PM-Kisan" : i % 3 === 1 ? "Fertilizer Subsidy" : "Irrigation Support",
    amount: randInt(3000, 9000),
    eligible: true
  };

  // Assign 2 dealers per farmer (random)
  const dealers = pick(dealerPool, 2);

  farmers.push(
    new Farmer({
      farmerId,
      name,
      aadhaar,
      mobile,
      landHolding,
      crops,
      dealers,
      transactions: [], // to be filled below
      subsidyEligibility
    })
  );
}

// Generate exactly 50 transactions distributed across the 20 farmers
// Strategy: First 15 farmers get 3 transactions each (45), last 5 get 1 each (5) => total 50
let txnIndex = 0;
const baseDate = new Date("2025-11-20");

for (let i = 0; i < farmers.length; i++) {
  const f = farmers[i];
  const numTx = i < 15 ? 3 : 1;

  for (let j = 0; j < numTx; j++) {
    const dealer = f.dealers[randInt(0, f.dealers.length - 1)];
    const dateObj = new Date(baseDate);
    dateObj.setDate(baseDate.getDate() + ((txnIndex % 30) + 1)); // spread across ~30 days
    const dateStr = dateObj.toISOString().slice(0, 10); // YYYY-MM-DD

    f.transactions.push({
      date: dateStr,
      amount: randInt(4000, 15000),
      dealer: dealer.name
    });

    txnIndex++;
  }
}
