// server.js
import express from "express";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

import loginRoutes from "./routes/loginRoutes.js";
import profileRoutes from "./routes/profileRoutes.js";
import transactionsRoutes from "./routes/transactionsRoutes.js";
import dealersRoutes from "./routes/dealersRoutes.js";
import governmentSubsidyRoutes from "./routes/governmentSubsidyRoutes.js";
import fraudDetectionRoutes from "./routes/fraudDetectionRoutes.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// Static frontend
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.use("/api", loginRoutes);
app.use("/api/farmers", profileRoutes);
app.use("/api/farmers", transactionsRoutes);
app.use("/api/farmers", dealersRoutes);
app.use("/api/farmers", governmentSubsidyRoutes);
app.use("/api/farmers", fraudDetectionRoutes);

// Default document -> login
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

app.listen(PORT, () => {
  console.log(`✅ API + Frontend running on http://localhost:${PORT}`);
});
