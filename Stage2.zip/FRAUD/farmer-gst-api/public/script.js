// Theme handling: default to dark
const rootHtml = document.documentElement;
rootHtml.setAttribute("data-theme", localStorage.getItem("theme") || "dark");

function toggleTheme() {
  const next = rootHtml.getAttribute("data-theme") === "dark" ? "light" : "dark";
  rootHtml.setAttribute("data-theme", next);
  localStorage.setItem("theme", next);
}

// Auth helpers
function getTokenOrRedirect() {
  const token = localStorage.getItem("token");
  if (!token) window.location.href = "/login.html";
  return token;
}
function logout() {
  localStorage.removeItem("token");
  window.location.href = "/login.html";
}

// API base
const API_BASE = "/api/farmers";

// Charts
let transactionsChart, dealersChart, fraudChart;

function setBadge(el, text, type = null) {
  el.textContent = text;
  el.className = "badge";
  if (type === "success") el.classList.add("success");
  if (type === "danger") el.classList.add("danger");
}

async function fetchJson(url) {
  const token = getTokenOrRedirect();
  try {
    const res = await fetch(url, { headers: { Authorization: "Bearer " + token } });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`HTTP ${res.status}: ${text}`);
    }
    return await res.json();
  } catch (err) {
    return { error: err.message };
  }
}

// Render summaries (visual-first)
function renderProfileSummary(profile) {
  const el = document.getElementById("profileSummary");
  el.innerHTML = `
    <span class="pill">👤 <strong>${profile.name || "-"}</strong></span>
    <span class="pill">🌾 ${profile.landHolding || "-"}</span>
    <span class="pill">📱 ${profile.mobile || "-"}</span>
    <span class="pill">🆔 ${profile.aadhaar || "-"}</span>
    <span class="pill">🌿 ${Array.isArray(profile.crops) ? profile.crops.join(", ") : "-"}</span>
  `;
}

function renderSubsidySummary(subsidy) {
  const s = subsidy.subsidyEligibility || {};
  const el = document.getElementById("subsidySummary");
  el.innerHTML = `
    <span class="pill">🏷️ ${s.scheme || "-"}</span>
    <span class="pill">💸 ₹${s.amount ?? 0}</span>
    <span class="pill">${s.eligible ? "✅ Eligible" : "❌ Not eligible"}</span>
  `;
}

function renderTransactionsChart(transactions) {
  const ctx = document.getElementById("transactionsChart").getContext("2d");
  const labels = transactions.map(t => t.date);
  const data = transactions.map(t => t.amount);

  if (transactionsChart) transactionsChart.destroy();
  transactionsChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Amount (₹)",
        data,
        backgroundColor: rootHtml.getAttribute("data-theme") === "dark" ? "#27ae60aa" : "#27ae60",
        borderColor: "#27ae60",
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: getComputedStyle(document.body).getPropertyValue('--muted') } },
        y: { ticks: { color: getComputedStyle(document.body).getPropertyValue('--muted') } }
      }
    }
  });
}

function renderDealersChart(dealers, transactions) {
  const ctx = document.getElementById("dealersChart").getContext("2d");
  const dealerNames = dealers.map(d => d.name);
  const totals = dealers.map(d =>
    transactions.filter(t => t.dealer === d.name).reduce((sum, t) => sum + t.amount, 0)
  );
  const colors = ["#3498db", "#9b59b6", "#f1c40f", "#e67e22", "#2ecc71", "#1abc9c"];

  if (dealersChart) dealersChart.destroy();
  dealersChart = new Chart(ctx, {
    type: "pie",
    data: { labels: dealerNames, datasets: [{ data: totals, backgroundColor: colors }] },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: getComputedStyle(document.body).getPropertyValue('--muted') } } }
    }
  });
}

function renderFraudChart(probability = 0) {
  const ctx = document.getElementById("fraudChart").getContext("2d");
  const riskPct = Math.round((probability || 0) * 100);

  if (fraudChart) fraudChart.destroy();
  fraudChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Fraud Risk", "Safe"],
      datasets: [{ data: [riskPct, 100 - riskPct], backgroundColor: ["#e74c3c", "#2ecc71"] }]
    },
    options: { cutout: "70%", plugins: { legend: { display: false } } }
  });

  const badge = document.getElementById("fraudBadge");
  if (riskPct >= 50) setBadge(badge, `High risk (${riskPct}%)`, "danger");
  else setBadge(badge, `Low risk (${riskPct}%)`, "success");
}

async function loadData() {
  const loading = document.getElementById("loading");
  loading.classList.remove("hidden");

  const farmerId = document.getElementById("farmerId").value.trim();
  const gstin = document.getElementById("gstin").value.trim();

  const profile = await fetchJson(`${API_BASE}/${farmerId}/profile`);
  if (!profile.error) renderProfileSummary(profile);

  const transactions = await fetchJson(`${API_BASE}/${farmerId}/transactions`);
  const tx = transactions.transactions || [];
  renderTransactionsChart(tx);

  const dealers = await fetchJson(`${API_BASE}/${farmerId}/dealers`);
  renderDealersChart(dealers.dealers || [], tx);

  const subsidy = await fetchJson(`${API_BASE}/${farmerId}/subsidy`);
  if (!subsidy.error) renderSubsidySummary(subsidy);

  const fraud = await fetchJson(`${API_BASE}/${farmerId}/dealers/${gstin}/fraud-prediction`);
  renderFraudChart(fraud.fraudProbability || 0);

  loading.classList.add("hidden");
}

// Hook events
window.addEventListener("DOMContentLoaded", () => {
  const themeToggle = document.getElementById("themeToggle");
  const loadBtn = document.getElementById("loadBtn");
  const logoutBtn = document.getElementById("logoutBtn");

  if (themeToggle) themeToggle.addEventListener("click", toggleTheme);
  if (logoutBtn) logoutBtn.addEventListener("click", logout);
  if (loadBtn) loadBtn.addEventListener("click", loadData);

  // Auto-load if on dashboard
  if (document.getElementById("farmerId")) {
    getTokenOrRedirect();
    loadData();
  }
});
